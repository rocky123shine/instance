package com.tz.dream.architect.singleton.demo;

//测试
public class MainTest {

	public static void main(String[] args) {
		
	}
	
}
