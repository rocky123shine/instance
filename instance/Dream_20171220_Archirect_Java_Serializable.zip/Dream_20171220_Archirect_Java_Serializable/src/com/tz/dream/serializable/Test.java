package com.tz.dream.serializable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test {
	
	public static void main(String[] args) {
		//第一步：序列化->保存对象
		serializableOrderBean(new OrderBean("3456fgfbw3435", "购物", "998"));
		//第二步：反序列->读取对象
		OrderBean deserializeOrderBean = deserializeOrderBean();
		//打印对象属性值
		System.out.println(deserializeOrderBean.toString());
	}

	/**
	 * 序列化订单对象
	 * 
	 * @param orderBean
	 */
	public static void serializableOrderBean(OrderBean orderBean) {
		// 序列化对象的流
		ObjectOutputStream outputStream = null;
		try {
			outputStream = new ObjectOutputStream(new FileOutputStream(
					new File("/Users/yangshaohong/Desktop/"
							+ orderBean.getClass().getSimpleName() + ".txt")));
			outputStream.writeObject(orderBean);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static OrderBean deserializeOrderBean() {
		ObjectInputStream objectInputStream = null;
		try {
			objectInputStream = new ObjectInputStream(new FileInputStream(
					new File("/Users/yangshaohong/Desktop/"
							+ OrderBean.class.getSimpleName() + ".txt")));
			Object readObject = objectInputStream.readObject();
			return (OrderBean) readObject;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
