//
//  Singleton.hpp
//  Dream_20171220_Architect_Cpp_Singleton_Demo
//
//  Created by Dream on 2017/12/20.
//  Copyright © 2017年 Tz. All rights reserved.
//

#ifndef Singleton_hpp
#define Singleton_hpp

#include <stdio.h>
#include <iostream>
#include <pthread.h>
//头文件->定义类->声明->恶汉式
//很久没搞了
//class Singleton {
//
//    //构造方法私有化
//private:
//    Singleton();
//    //析构函数是否对象
//    ~Singleton();
//    //私有属性
//private:
//    static Singleton* singleton;
//    //公开的静态方法
//public:
//    static Singleton* instance();
//    void printString();
//};


//单例模式->懒汉式->线程安全
class Singleton {
    
    //构造方法私有化
private:
    Singleton();
    //析构函数是否对象
    ~Singleton();
    //私有属性
private:
    static Singleton* singleton;
    //多线程处理
    static pthread_mutex_t mutex;
    //公开的静态方法
public:
    static Singleton* instance();
    void printString();
};

#endif /* Singleton_hpp */
