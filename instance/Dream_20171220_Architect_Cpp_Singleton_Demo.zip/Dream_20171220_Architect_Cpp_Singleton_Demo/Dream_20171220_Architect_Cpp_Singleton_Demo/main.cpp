//
//  main.cpp
//  Dream_20171220_Architect_Cpp_Singleton_Demo
//
//  Created by Dream on 2017/12/20.
//  Copyright © 2017年 Tz. All rights reserved.
//

#include <iostream>
#include "Singleton.hpp"

int main(int argc, const char * argv[]) {
    Singleton* instance = Singleton::instance();
    instance->printString();
    
    Singleton* instance_1 = Singleton::instance();
    instance_1->printString();
    return 0;
}
