//
//  Singleton.cpp
//  Dream_20171220_Architect_Cpp_Singleton_Demo
//
//  Created by Dream on 2017/12/20.
//  Copyright © 2017年 Tz. All rights reserved.
//

#include "Singleton.hpp"


//实现

//构造方法
//Singleton::Singleton(){
//    std::cout << "构造方法 \n";
//}
//
////静态方法(C++语法)
//Singleton* Singleton::singleton = new Singleton();
//Singleton* Singleton::instance(){
//    return singleton;
//}
//
//void Singleton::printString(){
//    std::cout << "printString \n";
//}


//单例模式->懒汉式
Singleton::Singleton(){
    std::cout << "构造方法 \n";
    pthread_mutex_init(&mutex, NULL);
}

//静态方法(C++语法)
Singleton* Singleton::singleton = NULL;
Singleton* Singleton::instance(){
    //调用时候判定
    if (singleton == NULL) {
        //线程加锁
        pthread_mutex_lock(&mutex);
        if (singleton == NULL) {
            singleton = new Singleton();
        }
        //线程解锁
        pthread_mutex_unlock(&mutex);
    }
    return singleton;
}

void Singleton::printString(){
    std::cout << "printString \n";
}




