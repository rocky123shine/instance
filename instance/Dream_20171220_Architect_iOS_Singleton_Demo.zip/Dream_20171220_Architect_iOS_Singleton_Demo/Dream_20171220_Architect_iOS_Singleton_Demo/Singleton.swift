//
//  Singleton.swift
//  Dream_20171220_Architect_iOS_Singleton_Demo
//
//  Created by Dream on 2017/12/20.
//  Copyright © 2017年 Tz. All rights reserved.
//

import Cocoa

//Swift语言->单例模式->恶汉式
//class Singleton: NSObject {
//
//    static let instance = Singleton()
//
//    private override init(){
//        //构造方法私有化
//    }
//
//}

//Swift语言->单例模式->懒汉式->struct创建法
class Singleton: NSObject {
    
    static var instace: Singleton {
        struct StaticInstance {
            static let inst = Singleton()
        }
        return StaticInstance.inst;
    }
    
    private override init(){
        //构造方法私有化
    }
    
}
